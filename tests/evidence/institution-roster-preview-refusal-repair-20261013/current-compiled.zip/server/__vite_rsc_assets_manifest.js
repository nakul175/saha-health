export default {
  "bootstrapScriptContent": "import(\"/_next/static/chunks/index-DXU0Hhcd.js\")",
  "clientReferenceDeps": {
    "df3ac243412b": {
      "js": [
        "/_next/static/chunks/page-B-IP8O1n.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/indicator-registry-panel-DuG2jGub.js",
        "/_next/static/chunks/select-CIenQlod.js",
        "/_next/static/chunks/framework-YrLwah_k.js",
        "/_next/static/chunks/index-DXU0Hhcd.js"
      ],
      "css": []
    },
    "2ada934e6967": {
      "js": [
        "/_next/static/chunks/page-DwuA-3fy.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/reporting-completeness-notice-DreO-6_O.js",
        "/_next/static/chunks/framework-YrLwah_k.js",
        "/_next/static/chunks/index-DXU0Hhcd.js"
      ],
      "css": []
    },
    "0da17c097593": {
      "js": [
        "/_next/static/chunks/institution-roster-review-19GhGeCe.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-YrLwah_k.js",
        "/_next/static/chunks/types-CuxIyc04.js",
        "/_next/static/chunks/index-DXU0Hhcd.js"
      ],
      "css": [
        "/_next/static/css/institution-roster-review.Bxyx2Aq9.css"
      ]
    },
    "1cb187e5e363": {
      "js": [
        "/_next/static/chunks/page-CI1OXGBA.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-YrLwah_k.js",
        "/_next/static/chunks/index-DXU0Hhcd.js"
      ],
      "css": []
    },
    "80112a1b2a5c": {
      "js": [
        "/_next/static/chunks/routine-visit-DNznsPHb.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/programmes-Bhl3fKc0.js",
        "/_next/static/chunks/select-CIenQlod.js",
        "/_next/static/chunks/framework-YrLwah_k.js",
        "/_next/static/chunks/types-CuxIyc04.js",
        "/_next/static/chunks/index-DXU0Hhcd.js"
      ],
      "css": [
        "/_next/static/css/routine-visit.BHynHarv.css",
        "/_next/static/css/programmes.CaW0-nlR.css"
      ]
    },
    "981306d2ffb2": {
      "js": [
        "/_next/static/chunks/today-Caq4r3DP.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-YrLwah_k.js",
        "/_next/static/chunks/index-DXU0Hhcd.js"
      ],
      "css": [
        "/_next/static/css/today.DZq1cVxx.css"
      ]
    },
    "195819d0e46b": {
      "js": [
        "/_next/static/chunks/workspace-BzLRIcD-.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/index-DXU0Hhcd.js",
        "/_next/static/chunks/framework-YrLwah_k.js",
        "/_next/static/chunks/programmes-Bhl3fKc0.js",
        "/_next/static/chunks/select-CIenQlod.js",
        "/_next/static/chunks/types-CuxIyc04.js",
        "/_next/static/chunks/indicator-registry-panel-DuG2jGub.js",
        "/_next/static/chunks/reporting-completeness-notice-DreO-6_O.js"
      ],
      "css": [
        "/_next/static/css/workspace.BpRC43vr.css",
        "/_next/static/css/programmes.CaW0-nlR.css"
      ]
    },
    "cabbef389f00": {
      "js": [
        "/_next/static/chunks/index-DXU0Hhcd.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-YrLwah_k.js"
      ],
      "css": []
    },
    "f0e66d4f0eed": {
      "js": [
        "/_next/static/chunks/index-DXU0Hhcd.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-YrLwah_k.js"
      ],
      "css": []
    },
    "abb120e07097": {
      "js": [
        "/_next/static/chunks/index-DXU0Hhcd.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-YrLwah_k.js"
      ],
      "css": []
    },
    "3462a99b6710": {
      "js": [
        "/_next/static/chunks/index-DXU0Hhcd.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-YrLwah_k.js"
      ],
      "css": []
    },
    "5238c988b74b": {
      "js": [
        "/_next/static/chunks/layout-segment-context-Ssuv8EMv.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/index-DXU0Hhcd.js",
        "/_next/static/chunks/framework-YrLwah_k.js"
      ],
      "css": []
    },
    "eef496938a22": {
      "js": [
        "/_next/static/chunks/index-DXU0Hhcd.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-YrLwah_k.js"
      ],
      "css": []
    },
    "32f3f579585d": {
      "js": [
        "/_next/static/chunks/streamed-icons-CsOTtuiM.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-YrLwah_k.js",
        "/_next/static/chunks/index-DXU0Hhcd.js"
      ],
      "css": []
    }
  },
  "serverResources": {
    "app/layout.tsx": {
      "js": [],
      "css": [
        "/_next/static/css/index.YeoBmIFq.css"
      ]
    }
  }
}