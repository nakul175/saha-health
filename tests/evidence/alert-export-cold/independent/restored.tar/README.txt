Saha organisation data export 84d6c460-db33-4642-bee5-307ebbe8888d
Uncertified historical care-reporting alert records are omitted from ordinary export. Linked protected audit content retains only its existing chain digest. Original server history is retained; no historical aggregate reconstruction is certified.
Organisation: Synthetic historical aggregate export
Generated (UTC): 2026-10-05T21:57:13.856Z

This archive holds the organisation's stored records in the exporter's authorised scope.
Synthetic development data only; no real patient data is permitted in this system.

Files
  manifest.json     export id, time, exporter, schema version, scope, and every file with row count, bytes and SHA-256
  SHA256SUMS        checksums of every other file (check with: sha256sum -c SHA256SUMS)
  tables/*.jsonl    one JSON object per stored row; keys are the stored column names
  media/*           photo and voice-note content; the sha256 column of tables/media.jsonl is its
                    SHA-256 in base64 (as computed at upload); SHA256SUMS lists it in hex
  handover/open-items.jsonl  unresolved external actions and open patient tasks with their named owner
  fhir/*.json       optional FHIR R4 document per current confirmed visit

Relationships
  patients.id is referenced by person_id in visits, submissions, referrals, record_revisions,
  media, rights_requests, audit_events and command_receipts; visits.id by visit_id in plans,
  ai_results, submissions and media; teams.id by team_id; accounts.user_id by user_id,
  actor_id, created_by and assigned_to. Included indicator_figures.parent_id refers to another
  included figure; indicator_figure_events and validated receipts refer to included figure/event ids.
  Figure data, counting units and private completeness snapshot bodies are protected and omitted; this is not full report or completeness reconstruction. Calendar policy, review/release history, declared source evidence and fixed receipt references follow current whole configured-team reporting scope. Exported snapshot hashes cannot reconstruct the omitted original body.
  Columns named data, changes, counts and team_ids are JSON text.

Audit chain
  audit_events rows with seq form one chain. content = SHA-256 of
  JSON.stringify([org_id,id,person_id,actor_id,actor_name,role,action,subject,detail,at]);
  hash = SHA-256 of JSON.stringify(['saha-audit-chain-v1',seq,prev_hash,content]); seq 0 is the
  genesis marker with prev_hash of 64 zeros. Rows marked "withheld" carry only their content digest.

Checking
  Files are listed in the manifest in an order that satisfies foreign keys for re-import.
  node scripts/verify-export.mjs <archive.tar>   (from the Saha source) checks the manifest,
  checksums, row counts, relationships, media and the audit chain without the application.
